function sendToNative(event) {
    var native = window.webkit.messageHandlers.nativeProcess;
    native.postMessage(event.detail);
}

function sendToWeb(eventName, eventDetail) {
   const event = new CustomEvent(eventName, { detail: eventDetail });
   window.dispatchEvent(event);
}

function subscribeToEvent(eventName) {
    window.addEventListener(eventName, sendToNative);
}

function patchTextFields() {
    for (i of document.getElementsByTagName("input")) {
        i.autocomplete = false
        i.autocorrect = false
    }
    return `Patched ${document.getElementsByTagName("input").length} elements`
}

function patchInputCreation() {
    const config = { attributes: true, childList: true, subtree: true };
    const callback = function(mutationsList, observer) {
        for(var i=0; i<mutationsList.length; ++i) {
            for(var j=0; j<mutationsList[i].addedNodes.length; ++j) {
                node = mutationsList[i].addedNodes[j]
                if (node.tagName == "BODY")
                if (node.tagName == "APP-USER-DETAILS-FORM" || node.tagName == "APP-USER-BASICS-FORM" || node.tagName == "APP-USER-BASICS-VIEW" || node.tagName == "MAT-ACCORDION") {
                    for (input of node.getElementsByTagName("input")) {
                        input.autocomplete = false
                        input.autocorrect = false
                    }
                    for (button of node.getElementsByClassName("add-btn")) {
                        addEventListener("click", function() {
                            setTimeout(patchTextFields, 500)
                        })
                    }
                }
            }
        }
    };
    const observer = new MutationObserver(callback);
    observer.observe(document, config);
}
